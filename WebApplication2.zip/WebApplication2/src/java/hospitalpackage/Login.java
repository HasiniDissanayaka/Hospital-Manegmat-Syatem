/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospitalpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;





/**
 *
 * @author Hasini Sewwandi
 */
class Login {

    private String driver="com.mysql.jdbc.Driver";
    private String url="jdbc:mysql://localhost:3306/logindatabase";
    Statement st;

    void addLogin(String name, String pass) {
        connectToDb();
        String sql="INSERT INTO logintbl VALUES('"+name+"','"+pass+"')";
        try {
            st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void connectToDb() {
        try {
            Class.forName(driver);
            Connection con=DriverManager.getConnection(url, "root","");
            st=con.createStatement();
        } catch (ClassNotFoundException|SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
